﻿
Partial Class BooksTable
    Inherits System.Web.UI.Page

End Class
