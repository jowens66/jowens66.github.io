﻿
Partial Class CustomSQL
    Inherits System.Web.UI.Page

End Class
