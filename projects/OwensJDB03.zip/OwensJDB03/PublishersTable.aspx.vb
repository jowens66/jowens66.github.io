﻿
Partial Class PublishersTable
    Inherits System.Web.UI.Page

End Class
